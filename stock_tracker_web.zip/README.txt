# Stock Portfolio Tracker Web App

## How to Use:
1. Make sure Python is installed.
2. Open terminal/cmd inside this folder.
3. Run the command: `python app.py`
4. Open your browser and go to: http://127.0.0.1:5000/
